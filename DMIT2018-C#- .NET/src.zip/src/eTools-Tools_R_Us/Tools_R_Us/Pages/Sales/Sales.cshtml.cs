using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Sales_System.BLL;
using Sales_System.ViewModels;

namespace Tools_R_Us.Pages.Sales
{
    public class SalesModel : PageModel
    {
        private readonly CategoryServices _categoryServices;
        private readonly StockServices _stockServices;

        public SalesModel(CategoryServices categoryServices, StockServices stockServices)
        {
            _categoryServices = categoryServices;
            _stockServices = stockServices;

        }

        [TempData]
        public string Feedback { get; set; }

        [BindProperty]
        public List<Fetch_Category> Category_List { get; set; }

        [BindProperty]
        public List<Fetch_Stock_Item> Stock_Items_List { get; set; }

        [BindProperty] public int CategoryId { get; set; }

        [BindProperty] public int StockItemID { get; set; }
        [BindProperty] public bool Shopping { get; set; }
        [BindProperty] public bool ViewCart { get; set; }
        [BindProperty] public bool Checkout { get; set; }

        public void OnGet()
        {
            PopulateCategories();
            Shopping = true;
        }

        public void PopulateCategories()
        {
            Category_List = _categoryServices.Fetch_Category();
        }


        public IActionResult OnPostCategoryItems()
        {
            PopulateCategories();

            Stock_Items_List = _stockServices.Fetch_CartItems_By(CategoryId);

            Shopping = true;
            ViewCart = false;
            Checkout = false;

            return Page();
        }





    }
   
}
