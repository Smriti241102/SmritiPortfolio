using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Receiving_Subsytem.BLL;
using Receiving_Subsytem.ViewModels;
using Receiving_Subsytem.Entities;

namespace Tools_R_Us.Pages.Receive
{
    public class ReceiveOrderModel : PageModel
    {
        [BindProperty(SupportsGet = true)]
        public string Feedback { get; set; }
        public string ErrorMsg { get; set; }

        [BindProperty(SupportsGet = true)]
        public int POId { get; set; }

        

        [BindProperty(SupportsGet =true)]
        public int employeeId { get; set; }

        [BindProperty(SupportsGet = true)]
        public List<PODetails> receivinglist { get; set; } = new List<PODetails>();

      
        [BindProperty]
        public List<UnorderedReturns> unorderedReturns { get; set; }= new();

        //[BindProperty]
        //public UnorderedReturns newitem { get; set; }
        [BindProperty]
        public int ID { get; set; }


        [BindProperty]
        public string Description { get; set; }

        [BindProperty]
        public string VSN { get; set; }

        [BindProperty]
        public int Qty { get; set; }

        [BindProperty]
        public int RemoveID { get; set; }

        [BindProperty]
        public string reason { get; set; }

        private readonly ReceivingServices _receivingServices;
        public List<Employee> employees { get; set; }

        public ReceiveOrderModel(ReceivingServices receivingServices)
        {
            _receivingServices = receivingServices;
            employees = _receivingServices.GetEmployees();
        }
        
        
        //public List<PODetails> OrderDetails { get; set; }
        public void OnGet()
        {

            if (receivinglist.Count == 0 || receivinglist ==null)
            {
                receivinglist = _receivingServices.PO_FetchPOInfo(POId);
            }
            


        }

        public IActionResult OnPostAdd()
        {
            Feedback = receivinglist[2].ReceivedQty.ToString();

            try
            {
                _receivingServices.Receive_ReceiveItems(POId, employeeId, receivinglist, unorderedReturns);

                Feedback += "Order Receiving Completed!";
                return RedirectToPage("/Receive/ReceiveOrder", new {POId = POId, Feedback = Feedback });

            }
            catch (Exception ex)
            {
                ErrorMsg = ex.Message;
            }

            return Page();
        }

        public IActionResult OnPostRemove()
        {
            
            
            try
            {
                var item = unorderedReturns.Where(x => x.ID == RemoveID).FirstOrDefault();

                if (item != null)
                {
                    unorderedReturns.Remove(item);
                }
                else
                {
                    ErrorMsg = $"Cannot remove item!";
                }
            }
            catch(Exception ex)
            {
                ErrorMsg=ex.Message;
            }

            return Page();

        }

        public IActionResult OnPostInsert()
        {
          

            
            try
            {
                if (ID == null || ID == 0)
                {
                    throw new Exception("Please Provide valid CID to be inserted");
                }
                if (string.IsNullOrWhiteSpace(Description))
                {
                    throw new Exception("Please provide Description of the item to be inserted.");
                }
                if(VSN ==null || string.IsNullOrWhiteSpace(VSN))
                {
                    throw new Exception("Please Provide valid VSN");
                }
                if(Qty == null || Qty < 1)
                {
                    throw new Exception("Please provide Quantity of the item to be returned");
                }
                UnorderedReturns newreturn = new UnorderedReturns();
                newreturn.ID = ID;
                newreturn.Description = Description;
                newreturn.VSN = VSN;
                newreturn.Qty = Qty;

                unorderedReturns.Add(newreturn);
               
            }
            catch(Exception ex)
            {
                ErrorMsg=(ex.Message); 
            }
             
            return Page();

        }

        public IActionResult OnPostClose()
        {
            

            try
            {
                if (string.IsNullOrEmpty(reason))
                {
                    throw new Exception("PLease Provide reason for force Close");
                    
                }
                _receivingServices.Force_Close(POId, reason, receivinglist);
                string feedback = "The Purchase Order Was closed";
                return RedirectToPage("/Receive/Receiving", new {Feedback = feedback});
            }
            catch(Exception ex)
            {
                ErrorMsg= ex.Message;
                return Page();
            }

            return Page();
        }
    }
}
