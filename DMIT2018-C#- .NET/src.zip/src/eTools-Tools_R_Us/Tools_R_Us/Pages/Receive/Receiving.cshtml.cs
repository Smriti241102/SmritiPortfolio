using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Receiving_Subsytem.BLL;
using Receiving_Subsytem.ViewModels;


namespace Tools_R_Us.Pages.Receive
{
    public class ReceivingModel : PageModel
    {

        //private
        private readonly ReceivingServices _receivingServices;
         
        [BindProperty(SupportsGet = true)]
        public string Feedback { get; set; }

        public ReceivingModel(ReceivingServices receivingServices)
        {
            _receivingServices = receivingServices;

        }

        public List<POList> OutstandingOrders { get; set; }

        public void OnGet()
        {
            OutstandingOrders = _receivingServices.PO_FetchPO();
        }
    }
}
