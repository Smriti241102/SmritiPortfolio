using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Receiving_Subsytem.BLL;
using Receiving_Subsytem.ViewModels;
using Receiving_Subsytem.Entities;
using Receiving_Subsytem.DAL;

namespace Tools_R_Us.Pages
{
    public class ReceivingModel : PageModel
    {

        //private
        private readonly ReceivingServices _receivingServices;


        public ReceivingModel(ReceivingServices receivingServices)
        {
            _receivingServices = receivingServices;

        }

        public List<POList> OutstandingOrders { get; set; }

        public void OnGet()
        {
            OutstandingOrders = _receivingServices.PO_FetchPO(); 
        }
    }
}
