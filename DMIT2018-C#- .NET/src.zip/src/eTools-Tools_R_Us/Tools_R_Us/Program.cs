using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Receiving_Subsytem;
using Sales_System;
using Tools_R_Us.Data;

var builder = WebApplication.CreateBuilder(args);
var SalesConnectionString = builder.Configuration.GetConnectionString("SalesConnection");
var ReceivingConnectionString = builder.Configuration.GetConnectionString("ReceivingConnectionString");

// Add services to the container.
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));

builder.Services.SalesBackendDependencies(options =>
    options.UseSqlServer(SalesConnectionString));

builder.Services.ReceivingBackendDependencies(options =>
    options.UseSqlServer(ReceivingConnectionString));




builder.Services.AddDatabaseDeveloperPageExceptionFilter();

builder.Services.AddDefaultIdentity<IdentityUser>(options => options.SignIn.RequireConfirmedAccount = true)
    .AddEntityFrameworkStores<ApplicationDbContext>();
builder.Services.AddRazorPages();

//Sales connection string 
var connectionStringSales = builder.Configuration.GetConnectionString("SalesConnection");

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseMigrationsEndPoint();
}
else
{
    app.UseExceptionHandler("/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapRazorPages();

app.Run();
