﻿namespace Purchasing_System
{
    public class Class1
    {

    }
}