﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Receiving_Subsytem.ViewModels
{
    public class PODetails
    {
        public int StockItemID { get; set; }
        public string Description { get; set; }
        public int Quantity { get; set; }
        public int OutstandingQty { get; set; }
        public int? ReceivedQty { get; set; }
        public int? ReturnedQty { get; set; }
        public string? Reason { get; set; }
    }
}
