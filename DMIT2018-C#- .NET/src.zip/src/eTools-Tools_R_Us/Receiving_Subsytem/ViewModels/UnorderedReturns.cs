﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Receiving_Subsytem.ViewModels
{
    public class UnorderedReturns
    {
        public int ID { get; set; }
        public string Description { get; set; }
        public string VSN { get; set; }
        public int Qty { get; set; }
    }
}
