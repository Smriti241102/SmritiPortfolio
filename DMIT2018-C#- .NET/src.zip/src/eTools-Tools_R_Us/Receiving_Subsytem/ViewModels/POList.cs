﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Receiving_Subsytem.ViewModels
{
    public class POList
    {
        public int PurchaseOrderID { get; set; }
        public DateTime? OrderDate { get; set; }
        public int VendorID { get; set; }
        public string Phone { get; set; }
    }
}
