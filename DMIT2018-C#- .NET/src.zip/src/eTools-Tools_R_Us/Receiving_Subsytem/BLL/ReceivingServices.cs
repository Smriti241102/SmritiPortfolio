﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Receiving_Subsytem.DAL;
using Receiving_Subsytem.ViewModels;
using Receiving_Subsytem.Entities;
using Microsoft.EntityFrameworkCore.Migrations.Operations;

namespace Receiving_Subsytem.BLL
{
    public class ReceivingServices
    {
        private readonly eTools2021Context _context;

        internal ReceivingServices(eTools2021Context context)
        {
            _context = context;
        }

        //TRX methods

		public List<Employee> GetEmployees()
        {
			return _context.Employees
				.ToList();
        }
        public List<POList> PO_FetchPO()
        {
            IEnumerable<POList> results =  _context.PurchaseOrders
			.Where(x => x.Closed == false && x.OrderDate!=null)
            .Select(x => new POList()
            {
                PurchaseOrderID = x.PurchaseOrderID,
                OrderDate = x.OrderDate,
                VendorID = x.VendorID,
                Phone = x.Vendor.Phone,
            });

			return results.ToList();
        }

        public List<PODetails> PO_FetchPOInfo(int PoId)
        {
            return _context.PurchaseOrderDetails
            .Where(x => x.PurchaseOrderID == PoId)
            .Select(x => new PODetails()
            {
                StockItemID = x.StockItemID,
                Description = x.StockItem.Description,
                Quantity = x.Quantity,
                OutstandingQty = x.Quantity - x.ReceiveOrderDetails.Sum(x => x.QuantityReceived)

            }).ToList();
        }

		public void Receive_ReceiveItems(int POId, int employeeID, List<PODetails> receivingList, List<UnorderedReturns> returnlist)
		{


			if (POId == null || POId == 0)
			{
				throw new Exception("PO ID not supplied!");
			}
			if (employeeID == null || employeeID == 0)
			{
				throw new Exception("EmployeeID not supplied!");
			}
			if (receivingList == null || receivingList.Count() == 0)
			{
				throw new Exception("No items have been supplied in the receiving list!");
			}
			bool listnotempty = false;

			foreach (var item in receivingList)
            {
				  if(item.ReceivedQty > 0)
                {
					listnotempty = true;
                }
            }
			foreach (var item in returnlist)
            {
				if(item.Qty > 0)
                {
					listnotempty = true;
                }
            }
			if(listnotempty == false)
            {
				throw new Exception("No receiving item or Unordered item to process");
            }

			foreach (var item in receivingList)
			{
				if (item.ReturnedQty != null && item.ReturnedQty > 0 && item.Reason == null)
				{
					throw new Exception("You need to supply Reason if returning an item!");
				}
				StockItem stockitem1 = _context.StockItems.Where(x => x.StockItemID == item.StockItemID).FirstOrDefault();
				if (item.ReceivedQty > stockitem1.QuantityOnOrder || item.ReceivedQty >item.OutstandingQty)
				{
					throw new Exception("Receiving Quantity can not be more than Quantity Ordered!");
				}
			}


			PurchaseOrder poOrder = _context.PurchaseOrders.Where(x => x.PurchaseOrderID == POId).FirstOrDefault();

			ReceiveOrder newOrder = new ReceiveOrder();
			newOrder.PurchaseOrderID = POId;
			newOrder.ReceiveDate = DateTime.Now;
			newOrder.EmployeeID = employeeID;
			_context.ReceiveOrders.Add(newOrder);

			foreach (var item in receivingList)
			{
				PurchaseOrderDetail podetail = _context.PurchaseOrderDetails.Where(x => x.PurchaseOrderID == POId && x.StockItemID == item.StockItemID).FirstOrDefault();

				if (item.ReceivedQty > 0)
				{

					ReceiveOrderDetail newOrderDetails = new ReceiveOrderDetail();
					newOrderDetails.QuantityReceived = item.ReceivedQty == null ? 0 : (int)item.ReceivedQty;
					//Add to THE received Order & PODetails table
					newOrder.ReceiveOrderDetails.Add(newOrderDetails);
					podetail.ReceiveOrderDetails.Add(newOrderDetails);
				}


					//returnedOrder Details table update
					if (item.ReturnedQty > 0)
					{
						ReturnedOrderDetail returnitem = new()
						{
							ItemDescription = item.Description,
							Quantity = (int)item.ReturnedQty,
							Reason = (string)item.Reason,
							VendorStockNumber = _context.StockItems
												.Where(x => x.StockItemID == item.StockItemID)
												.Select(x => x.VendorStockNumber)
												.FirstOrDefault()
						};
						//Add item returned to returned table
						podetail.ReturnedOrderDetails.Add(returnitem);
						newOrder.ReturnedOrderDetails.Add(returnitem);
					}


					//update StockItems table
					StockItem stockitem = _context.StockItems.Where(x => x.StockItemID == item.StockItemID).FirstOrDefault();


					stockitem.QuantityOnHand += item.ReceivedQty == null ? 0 : (int)item.ReceivedQty;
					stockitem.QuantityOnOrder -= item.ReceivedQty == null ? 0 : (int)item.ReceivedQty;

					_context.StockItems.Update(stockitem);
				

			}

			if (returnlist != null && returnlist.Count() > 0)
			{
				foreach (var item in returnlist)
				{
					UnOrderedItem unordered = new();
					unordered.ItemName = item.Description;
					unordered.VendorProductID = item.VSN;
					unordered.Quantity = item.Qty;

					_context.UnOrderedItems.Add(unordered);
				}
			}

			bool close = true;
			foreach (var item in receivingList)
			{
				if (item.OutstandingQty != item.Quantity)
				{
					close = false;
				}
			}

			if (close == true)
			{

				poOrder.Closed = true;
				_context.PurchaseOrders.Update(poOrder);

			}

			_context.SaveChanges();



		}

		public void Force_Close(int POId, string reason, List<PODetails> list)
		{
			if (POId == null || POId == 0)
			{
				throw new Exception("PO ID not supplied!");
			}

			if (String.IsNullOrEmpty(reason))
            {
				throw new Exception("Reason needs to be supplied in order to force Close");
            }
			if (list == null || list.Count() == 0)
			{
				throw new Exception("No items have been supplied in the receiving list ID not supplied!");
			}

			PurchaseOrder poOrder = _context.PurchaseOrders.Where(x => x.PurchaseOrderID == POId).FirstOrDefault();
			poOrder.Closed = true;
			poOrder.Notes = reason;
			_context.PurchaseOrders.Update(poOrder);

			foreach (var item in list)
            {
				StockItem stockitem = _context.StockItems.Where(x => x.StockItemID == item.StockItemID).FirstOrDefault();
				stockitem.QuantityOnOrder = 0;
			}

			_context.SaveChanges();
		}

	}

	
}
