﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Receiving_Subsytem.BLL;
using Receiving_Subsytem.DAL;


namespace Receiving_Subsytem
{
    public static class ReceivingExtensions
    {
        public static void ReceivingBackendDependencies(this IServiceCollection services,
        Action<DbContextOptionsBuilder> options)
        {
            services.AddDbContext<eTools2021Context>(options);

            services.AddTransient<ReceivingServices>((serviceProvider) =>
            {
                var context = serviceProvider.GetRequiredService<eTools2021Context>();

                return new ReceivingServices(context);
            });

        }

    }
}