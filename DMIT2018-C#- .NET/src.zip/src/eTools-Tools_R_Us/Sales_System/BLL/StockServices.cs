﻿using Sales_System.DAL;
using Sales_System.Entities;
using Sales_System.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sales_System.BLL
{
    public class StockServices
    {
        private eTools2021Context _context;

        internal StockServices(eTools2021Context context)
        {
            _context = context;
        }
        public List<Fetch_Stock_Item> Fetch_CartItems_By(int categoryID)
        {
            IEnumerable<Fetch_Stock_Item> info = _context.StockItems
                            .Where(x => x.CategoryID == categoryID)
                            .Select(x => new Fetch_Stock_Item
                            {
                                StockItemID = x.StockItemID,
                                Description = x.Description,
                                QuantityOnHand = x.QuantityOnHand,
                                SellingPrice = x.SellingPrice
                            }).ToList();

            return info.ToList();
        }
    }
}
