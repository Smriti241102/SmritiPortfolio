﻿using Sales_System.DAL;
using Sales_System.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sales_System.BLL
{
    public class CategoryServices
    {
        private eTools2021Context _context;

        internal CategoryServices(eTools2021Context context)
        {
            _context = context;
        }
        public List<Fetch_Category> Fetch_Category()
        {
            IEnumerable<Fetch_Category> data = _context.Categories
                                        .Select(x => new Fetch_Category
                                        {
                                            CategoryID = x.CategoryID,
                                            Description = x.Description,
                                            StockItemsCount = x.StockItems.Count()
                                        }).ToList();

            return data.ToList();
        }
    }
}
