﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Sales_System.BLL;
using Sales_System.DAL;

namespace Sales_System;

public static class SalesExtensions
{
    public static void SalesBackendDependencies(this IServiceCollection services,
    Action<DbContextOptionsBuilder> options)
    {
        services.AddDbContext<eTools2021Context>(options);

        services.AddTransient<CategoryServices>((serviceProvider) =>
        {
            var context = serviceProvider.GetRequiredService<eTools2021Context>();

            return new CategoryServices(context);
        });

        services.AddTransient<StockServices>((serviceProvider) =>
        {
            var context = serviceProvider.GetRequiredService<eTools2021Context>();

            return new StockServices(context);
        });
    }
}