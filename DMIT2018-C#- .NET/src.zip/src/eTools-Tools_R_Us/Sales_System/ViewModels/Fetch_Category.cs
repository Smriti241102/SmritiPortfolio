﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sales_System.ViewModels
{
    public class Fetch_Category
    {
        public int CategoryID { get; set; }
        public string Description { get; set; }

        //updated 
        public int StockItemsCount { get; set; }
    }
}
