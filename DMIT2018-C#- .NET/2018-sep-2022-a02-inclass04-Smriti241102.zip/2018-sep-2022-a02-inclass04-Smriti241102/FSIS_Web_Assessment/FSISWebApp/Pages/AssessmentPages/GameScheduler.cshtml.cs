#nullable disable
using FSISSystem.BLL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

#region Additional Namespaces
using FSISSystem.BLL;
using FSISSystem.CQRSModels;
#endregion


namespace FSISWebApp.Pages.AssessmentPages
{
    public class GameSchedulerModel : PageModel
    {
        #region Private varailable and DI constructor DO NOT ALTER
        private readonly TeamServices _teamServices;
        private readonly GameServices _gameServices;

        public GameSchedulerModel(
                            TeamServices teamservices,
                            GameServices gameservices)
        {

            _teamServices = teamservices;
            _gameServices = gameservices;
        }
        #endregion

        #region Messaging and Error Handling DO NOT ALTER
        public string FeedBackMessage { get; set; }

        public string ErrorMessage { get; set; }

        //a get property that returns the result of the lamda action
        public bool HasError => !string.IsNullOrWhiteSpace(ErrorMessage);
        public bool HasFeedBack => !string.IsNullOrWhiteSpace(FeedBackMessage);

        //used to display any collection of errors on web page
        public List<string> ErrorDetails { get; set; } = new();

        //PageModel local error list for collection 
        public List<Exception> Errors { get; set; } = new();

        #endregion

        //use for dropdown list: Home Team
        public List<SelectionList> hometeamList { get; set; }
        //use for dropdown list: Visiting Team
        public List<SelectionList> visitteamList { get; set; }

        //variables used to collect data from the web page form
        int removeid { get; set; }

        // Game Date
        [BindProperty]
        public DateTime GameDate { get; set; } = DateTime.Today;

        //Home Team dropdown list value
        [BindProperty]
        public int HomeId { get;set; }

        //Visiting Team dropdown list value
        [BindProperty]
        public int VisitId { get; set; }

        //CQRS Command model collection to hold game for scheduling
        [BindProperty]
        public List<Schedule> gameSchedule { get; set; } = new();

        //Remove button value
        [BindProperty]
        public int SelectedGame { get; set; }

        //Do not alter this code
        #region DO NOT ALTER
        public void OnGet()
        {
            GetTeamLists();
        }

        public void GetTeamLists()
        {
            hometeamList = _teamServices.TeamServices_GetList();
            visitteamList = _teamServices.TeamServices_GetList();
        }

        private Exception GetInnerException(Exception ex)
        {
            while (ex.InnerException != null)
                ex = ex.InnerException;
            return ex;
        }

        public IActionResult OnPostClear()
        {
            return RedirectToPage();
        }
        #endregion

        //TODO: 1 Create web page table code
        //        Open the .cshtml page and add the code to handle the table for game scheduling

        public IActionResult OnPostAddToSchedule()
        {
            //TODO: 2 Implement Add to Schedule post
            
            //   YOUR CODE HERE

            // a) include user friendly error handling (see class demo). 
            //    your code must be able to collect all local errors and display the collection
            //    error handling variables have been created for you (see region above)
            // b) validation
            //    Game Date must be today or in the future
            //    Home team must be selected
            //    Visiting team must be selected
            // c) Valid Data
            //    create the next available Game Index value. this value is the maximum game index value
            //          on the CQRS command model collection plus one.
            //    create a new instance for the CQRS command model collection
            //    add to collection
            //    use Page() for your return.
            
            if(GameDate <DateTime.Now)
            {
                ErrorMessage = $"Game Date must be today or in the future";
            }
            if (HomeId == null)
            {
                ErrorMessage = $"Home team must be selected";
            }
            if (VisitId == null)
            {
                ErrorMessage = $"Visiting team must be selected";
            }

            try
            {
                Schedule schedule = new Schedule();
                if (gameSchedule.Count == 0)
                {
                    schedule.GameIndex = 1;
                }
                else
                {
                    schedule.GameIndex = gameSchedule.OrderBy(x => x.GameIndex)
                                                        .Max(x => x.GameIndex) + 1;
                }
                schedule.HomeTeamID = HomeId;
                schedule.VisitingTeamID = VisitId;

                gameSchedule.Add(schedule);
            }
            catch(Exception ex)
            {
                ErrorMessage = ex.Message;
            }


            GetTeamLists();
            return Page();
        }

        public IActionResult OnPostRemove()
        {
            //TODO: 3 Implement Remove from Schedule post

            //   YOUR CODE HERE

            // a) include user friendly error handling (see class demo). 
            //    your code must be able to display the collection of service class errors
            //    error handling variables have been created for you (see region above)
            // b) on page collection handling
            //    remove the selected game from the CQRS command model collection
            //    use Page() for your return.
            try
            {
                var gametoremove = gameSchedule.SingleOrDefault(x => x.GameIndex == SelectedGame);
                if (gametoremove != null)
                {
                    gameSchedule.Remove(gametoremove);
                }
                FeedBackMessage = "Game removed successfully!";
            }
            catch(Exception ex)
            {
                ErrorMessage=ex.Message;
            }
            return Page();
        }

        public IActionResult OnPostSchedule()
        {
            //TODO: 4 Implement Schedule (service transaction call) post

            //   YOUR CODE HERE

            // a) include user friendly error handling (see class demo). 
            //    your code must be able to display the collection of service class errors
            //    error handling variables have been created for you (see region above)
            // b) service method call
            //    use the GameServices method: GameServices_ScheduleGames(....)
            //    display a success message
            //    use Page() for your return.
            try
            {
                _gameServices.GameServices_ScheduleGames(GameDate, gameSchedule);
                FeedBackMessage = "Games Scheduled Successfully";
            }
            catch(Exception ex)
            {
                ErrorMessage = ex.Message;
            }

            

            return Page();
        }

 

    }
}
