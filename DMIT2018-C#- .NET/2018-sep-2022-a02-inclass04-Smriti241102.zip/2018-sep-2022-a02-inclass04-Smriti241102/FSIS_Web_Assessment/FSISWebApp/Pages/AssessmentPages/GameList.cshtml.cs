using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

#region Additional Namespaces
using FSISSystem.BLL;
using FSISSystem.CQRSModels;
#endregion


namespace FSISWebApp.Pages.AssessmentPages
{
    public class GameListModel : PageModel
    {
        #region Private varailable and DI constructor
        private readonly TeamServices _teamServices;
        private readonly GameServices _gameServices;

        public GameListModel(
                            TeamServices teamservices,
                            GameServices gameservices)
        {
          
            _teamServices = teamservices;
            _gameServices = gameservices;
        }
        #endregion

        public List<GameItem> Lastest50Games { get; set; }
        public void OnGet()
        {
            Lastest50Games = _gameServices.GameServices_GetList();
        }
    }
}
