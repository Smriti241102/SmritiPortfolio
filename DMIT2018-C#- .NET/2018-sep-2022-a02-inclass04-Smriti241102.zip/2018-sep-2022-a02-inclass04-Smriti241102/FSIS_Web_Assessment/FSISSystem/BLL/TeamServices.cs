﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#region Additional Namespaces
using FSISSystem.Entities;
using FSISSystem.DAL;
using FSISSystem.CQRSModels;
#endregion

namespace FSISSystem.BLL
{
    public class TeamServices
    {
        #region Constructor and Context Dependency
        private readonly FSIS_2018Context _context;

        //obtain the context link from IServiceCollection when this
        //  set of service is injected into the "outside user"
        internal TeamServices(FSIS_2018Context context)
        {
            _context = context;
        }
        #endregion

        #region Services:Queries
        public List<SelectionList> TeamServices_GetList()
        {
            IEnumerable<SelectionList> results = _context.Teams
                                                .OrderBy(x => x.TeamName)
                                                .Select(x => new SelectionList()
                                                {
                                                    ValueId = x.TeamID,
                                                    DisplayText = x.TeamName
                                                });
            return results.ToList();
        }
        #endregion
    }
}
