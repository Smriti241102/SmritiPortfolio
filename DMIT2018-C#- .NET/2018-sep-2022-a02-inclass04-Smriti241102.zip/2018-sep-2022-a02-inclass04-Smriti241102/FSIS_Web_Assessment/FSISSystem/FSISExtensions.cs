﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#region Additional Namespaces
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using FSISSystem.DAL;
using FSISSystem.BLL;
#endregion


namespace FSISSystem
{
    public static class FSISExtensions
    {
        public static void FSISSystemServiceDependencies(this IServiceCollection services,
           Action<DbContextOptionsBuilder> options)
        {
            //register the DbContext class in Chinook with the service collection
            services.AddDbContext<FSIS_2018Context>(options);

            //register service classes

            services.AddTransient<TeamServices>((serviceProvider) =>
            {
                var context = serviceProvider.GetRequiredService<FSIS_2018Context>();
                //create an instance of the service and return the instance
                return new TeamServices(context);
            });
            services.AddTransient<GameServices>((serviceProvider) =>
            {
                var context = serviceProvider.GetRequiredService<FSIS_2018Context>();
                //create an instance of the service and return the instance
                return new GameServices(context);
            });


        }
    }
}
