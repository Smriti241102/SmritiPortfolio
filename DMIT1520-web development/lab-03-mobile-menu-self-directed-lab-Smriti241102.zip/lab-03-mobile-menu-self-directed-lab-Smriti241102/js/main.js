//define constants
const clickButton = document.querySelector('.menu-icon');


//add click event
clickButton.addEventListener('click', () => {
    document.querySelector('nav').classList.toggle('active-nav');
})




